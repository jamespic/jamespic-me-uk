Rock, Paper, Scissors Bots
==========================

This archive contains versions of the competition winning
Roshambo bots, Iocaine Powder and Greenberg, modified to
allow them to play human opponents.

The bots, as well as the program itself, are modified from
the tournament suite used for The Second International
Roshambo Programming Competition (see 
http://www.cs.ualberta.ca/~darse/rsbpc.html for more info)

Included are binary executables for Windows and Linux i386,
compiled on MinGW and Ubuntu 6.06 respectively, as well as
the source for the modified versions, and the original
source files.

Simply unzip the archive, and run either ./roshambo on
Linux, or roshambo.exe on windows. You will be asked if you
want to play. If you choose yes, you'll play each bot in
turn, then they'll play each other, and you'll be shown the
results. If not, another bot, which always guesses randomly
will take your place.

If you wish to modify the source you can, as long as you
acknowledge the original author. Don't worry about
acknowledging me.

In case there was any confusion, there is no warranty, and
no technical support; and yes, I know my code's sloppy. If
you want to contact me, my email is james_pic@hotmail.com.

Have fun.