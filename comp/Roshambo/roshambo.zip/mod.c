
/*  RoShamBo Tournament Sample Program     Darse Billings,  Oct 1999  */
/*                                                                    */
/*  This program may be used and modified freely, as long as the      */
/*  original author credit is maintained.  There are no guarantees    */
/*  of any kind.  Use at your own risk.                               */
/*                                                                    */
/*  Check the main web page for future versions of this program:      */
/*                                                                    */
/*        http://www.cs.ualberta.ca/~darse/rsbpc.html                 */

/*  this version contains corrections to the table driven dummy bots  */
/*  (thanks to Michael Callahan for noticing this)  -drb 07/00        */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include <malloc.h>
#include <assert.h>
#include <sys/time.h>
#include <unistd.h>

#define rock      0
#define paper     1
#define scissors  2

#define players   3         /* number of players in the tournament */
#define trials    100       /* number of turns per match */
#define tourneys  1          /* number of round-robin tournaments */
#define drawn     50         /* +/- statistical draw range */
                             /* for 1000 trials rec: 50.6 / sqrt(tourneys) */

#define fw        4          /* field width for printed numbers */
#define verbose1  1          /* print result of each trial */
#define verbose2  0          /* print match histories */
#define verbose3  1          /* print result of each match */

/*  Full History Structure (global variables, accessible to the
                            current player during each match)

      - element 0 is the number of trials played so far
      - element i is the action taken on turn i (1 <= i <= trials ) */

int my_history[trials+1], opp_history[trials+1];

/*  Tournament Crosstable Structure  */

#define nameleng  18
typedef struct {
    char name[nameleng+1];   /* descriptive name (max 18 chars) */
    int(*pname)();           /* function name for computer player */
    int result[players+1];   /* list of player's match results */
} Player_Table;


int flip_biased_coin (double prob)
{
    /* flip an unfair coin (bit) with given probability of getting a 1 */

    if ( (rand() / ((double)RAND_MAX + 1)) >= prob )
         return(0);
    else return(1);
}

int biased_roshambo (double prob_rock, double prob_paper)
{
    /* roshambo with given probabilities of rock, paper, or scissors */
    double throw;

    throw = rand() / ((double)RAND_MAX + 1);

    if ( throw < prob_rock )                   { return(rock); }
    else if ( throw < prob_rock + prob_paper ) { return(paper); }
    else /* throw >= prob_rock + prob_paper */ { return(scissors); }
}

/*  The Bots  */

/* Randbot */

int randbot ()  /* Random (Optimal) */
{
    /* generate action uniformly at random (optimal strategy) */
    return( rand() % 3);
}

/* unrandbot */

/* Greenberg */

#define T opp_history[0]

const int best_without[3] = { 2, 0, 1 };
const int wins_with[3] = { 1, 2, 0 };
const int score_table[3][3] = { { 0, -1, 1 }, { 1, 0, -1 }, { -1, 1, 0 } };

short int my_history_hash[4][trials];
short int opp_history_hash[4][trials];

int p_full[24][4];
int p_freq[2][2];
int p_random;

int gear[24][trials];

int r_full[24][2];
int r_freq[2][2];

int p_full_score[50][24][4][3];
int p_freq_score[50][2][2][3];
int p_random_score;
int r_full_score[50][24][2][3];
int r_freq_score[50][2][2][3];

const int lengths[6] = { 10, 20, 30, 40, 49, 0 };
int p_len[6];
int s_len[6];

int find_best_prediction(int len)
{
	int i,j,k;
	int bs = -trials, bp = 0;

	if (p_random_score > bs) { bs = p_random_score; bp = p_random; }

	for (i = 0; i < 3; i++) {
		for (j = 0; j < 24; j++) {
			for (k = 0; k < 4; k++) {
				if (p_full_score[T % 50][j][k][i] - (len ? p_full_score[(50+T-len)%50][j][k][i] : 0) > bs) {
					bs = p_full_score[T % 50][j][k][i] - (len ? p_full_score[(50+T-len)%50][j][k][i] : 0);
					bp = (p_full[j][k] + i) % 3;
				}
			}
			for (k = 0; k < 2; k++) {
				if (r_full_score[T%50][j][k][i]  - (len ? r_full_score[(50+T-len)%50][j][k][i] : 0)> bs) {
					bs = r_full_score[T%50][j][k][i] - (len ? r_full_score[(50+T-len)%50][j][k][i] : 0);
					bp = (r_full[j][k] + i) % 3;
				}
			}
		}
		for (j = 0; j < 2; j++) {
			for (k = 0; k < 2; k++) {
				if (p_freq_score[T%50][j][k][i]  - (len ? p_freq_score[(50+T-len)%50][j][k][i] : 0)> bs) {
					bs = p_freq_score[T%50][j][k][i] - (len ? p_freq_score[(50+T-len)%50][j][k][i] : 0);
					bp = (p_freq[j][k] + i) % 3;
				}
				if (r_freq_score[T%50][j][k][i]  - (len ? r_freq_score[(50+T-len)%50][j][k][i] : 0)> bs) {
					bs = r_freq_score[T%50][j][k][i] - (len ? r_freq_score[(50+T-len)%50][j][k][i] : 0);
					bp = (r_freq[j][k] + i) % 3;
				}
			}
		}
	}

	return bp;
}

void update_scores()
{
	int i,j,k;

	p_random_score += score_table[p_random][opp_history[T]];

	for (i = 0; i < 3; i++) {
		for (j = 0; j < 24; j++) {
			for (k = 0; k < 4; k++) {
				p_full_score[T%50][j][k][i] = p_full_score[(T+49)%50][j][k][i] + score_table[(p_full[j][k] + i) % 3][opp_history[T]];
			}
			for (k = 0; k < 2; k++) {
				r_full_score[T%50][j][k][i] = r_full_score[(T+49)%50][j][k][i] + score_table[(r_full[j][k] + i) % 3][opp_history[T]];
			}
		}
		for (j = 0; j < 2; j++) {
			for (k = 0; k < 2; k++) {
				p_freq_score[T%50][j][k][i] = p_freq_score[(T+49)%50][j][k][i] + score_table[(p_freq[j][k] + i) % 3][opp_history[T]];
				r_freq_score[T%50][j][k][i] = r_freq_score[(T+49)%50][j][k][i] + score_table[(r_freq[j][k] + i) % 3][opp_history[T]];
			}
		}
	}

	for (i = 0; i < 6; i++)
		s_len[i] += score_table[p_len[i]][opp_history[T]];
}

void init()
{
	int i,j,k,l;

	p_random_score = 0;

	for (i = 0; i < 3; i++) {
		for (j = 0; j < 24; j++) {
			for (k = 0; k < 4; k++) {
				for (l = 0; l < 50; l++) p_full_score[l][j][k][i] = 0;
			}
			for (k = 0; k < 2; k++) {
				for (l = 0; l < 50; l++) r_full_score[l][j][k][i] = 0;
			}
		}
		for (j = 0; j < 2; j++) {
			for (k = 0; k < 2; k++) {
				for (l = 0; l < 50; l++) p_freq_score[l][j][k][i] = 0;
				for (l = 0; l < 50; l++) r_freq_score[l][j][k][i] = 0;
			}
		}
	}
	for (i = 0; i < 6; i++) s_len[i] = 0;
}

int find_min_index(int * table, int length)
{
	int i, min = 123456, min_i = -1;
	for (i = 0; i < length; i++) if (table[i] <= min) { min_i = i; min = table[i]; }
	return min_i;
}

int find_max_index(int * table, int length)
{
	int i, max = -123456, max_i = -1;
	for (i = 0; i < length; i++) if (table[i] >= max) { max_i = i; max = table[i]; }
	return max_i;
}

void make_predictions()
{
	int i,j,k,l;
	int f[3][2][4][3];
	int t[3][2][4];

	int m_len[3][trials];
	static int freq[2][3];

	int value[2][3] = { { 0, 0, 0 }, { 0, 0, 0 } };

	int gear_freq[3];

	p_random = biased_roshambo(0.3333,0.3333);

	for (i = 0; i < 24; i++) {
		gear[i][T] = (3 + opp_history[T] - p_full[i][2]) % 3;
		if (T > 1) gear[i][T] += 3 * gear[i][T-1];
		gear[i][T] = gear[i][T] % 9;
	}

	if (T == 0) {
		for (i = 0; i < 2; i++)
			for (j = 0; j < 3; j++) freq[i][j] = 0;
	} else {
		freq[0][my_history[T]]++;
		freq[1][opp_history[T]]++;

		for (i = 0; i < 2; i++) {
			value[i][0] = (1000 * (freq[i][2] - freq[i][1])) / T;
			value[i][1] = (1000 * (freq[i][0] - freq[i][2])) / T;
			value[i][2] = (1000 * (freq[i][1] - freq[i][0])) / T;
		}
	}

	for (i = 0; i < 2; i++) {
		p_freq[i][0] = wins_with[find_max_index(freq[i], 3)];
		p_freq[i][1] = wins_with[find_max_index(value[i], 3)];

		r_freq[i][0] = best_without[find_min_index(freq[i], 3)];
		r_freq[i][1] = best_without[find_min_index(value[i], 3)];
	}

	for (i = 0; i < 3; i++)
		for (j = 0; j < 2; j++)
			for (k = 0; k < 4; k++)
				for (l = 0; l < 3; l++) {
					f[i][j][k][l] = 0;
					t[i][j][k] = 0;
				}

	for (i = T - 1; i > 0; i--) {
		m_len[0][i] = 4;
		for (j = 0; j < 4; j++)
			if (my_history_hash[j][i] != my_history_hash[j][T]) { m_len[0][i] = j; break; }
		m_len[1][i] = 4;
		for (j = 0; j < 4; j++)
			if (opp_history_hash[j][i] != opp_history_hash[j][T]) { m_len[1][i] = j; break; }
		m_len[2][i] = 4;
		for (j = 0; j < 4; j++)
			if (my_history_hash[j][i] != my_history_hash[j][T] ||
			    opp_history_hash[j][i] != opp_history_hash[j][T]) { m_len[2][i] = j; break; }
	}

	for (i = T - 1; i > 0; i--) {
		for (j = 0; j < 3; j++) {
			for (k = 0; k < m_len[j][i]; k++) {
				f[j][0][k][my_history[i + 1]]++; t[j][0][k]++;
				f[j][1][k][opp_history[i + 1]]++; t[j][1][k]++;

				if (t[j][0][k] == 1) {
					p_full[j * 8 + 0 * 4 + k][0] = wins_with[my_history[i + 1]];
				}
				if (t[j][1][k] == 1) {
					p_full[j * 8 + 1 * 4 + k][0] = wins_with[opp_history[i + 1]];
				}

				if (t[j][0][k] == 3) {
					p_full[j * 8 + 0 * 4 + k][1] = wins_with[find_max_index(f[j][0][k],3)];
					r_full[j * 8 + 0 * 4 + k][0] = best_without[find_min_index(f[j][0][k],3)];
				}

				if (t[j][1][k] == 3) {
					p_full[j * 8 + 1 * 4 + k][1] = wins_with[find_max_index(f[j][1][k],3)];
					r_full[j * 8 + 1 * 4 + k][0] = best_without[find_min_index(f[j][1][k],3)];
				}
			}
		}
	}

	for (j = 0; j < 3; j++) {
		for (k = 0; k < 4; k++) {
			p_full[j * 8 + 0 * 4 + k][2] = wins_with[find_max_index(f[j][0][k],3)];
			r_full[j * 8 + 0 * 4 + k][1] = best_without[find_min_index(f[j][0][k],3)];
	
			p_full[j * 8 + 1 * 4 + k][2] = wins_with[find_max_index(f[j][1][k],3)];
			r_full[j * 8 + 1 * 4 + k][1] = best_without[find_min_index(f[j][1][k],3)];
		}
	}

	for (j = 0; j < 24; j++) {
		for (i = 0; i < 3; i++) gear_freq[i] = 0;

		for (i = T - 1; i > 0; i--)
			if (gear[j][i] == gear[j][T]) gear_freq[gear[j][i + 1]]++;

		p_full[j][3] = (p_full[j][1] + find_max_index(gear_freq,3)) % 3;
	}

}

void update_history_hash()
{
	int i;

	if (T == 0) {
		for (i = 0; i < 4; i++) {
			my_history_hash[i][0] = 0;
			opp_history_hash[i][0] = 0;
		}

		return;
	}

	my_history_hash[0][T] = my_history[T];
	opp_history_hash[0][T] = opp_history[T];

	for (i = 1; i < 4; i++) {
		my_history_hash[i][T] = my_history_hash[i-1][T - 1] * 3 + my_history[T];
		opp_history_hash[i][T] = opp_history_hash[i-1][T - 1] * 3 + opp_history[T];
	}
}

int greenberg()
{
	int i;

	if (T == 0) {
		init(); fflush(stdout);
	} else {
		update_scores();
	}

	update_history_hash();
	make_predictions();

	for (i = 0; i < 6; i++) p_len[i] = find_best_prediction(lengths[i]);
	
	return p_len[find_max_index(s_len, 6)];
}

#undef T

/* ungreenberg */

/* iocaine */
#define will_beat(play) ("\001\002\000"[play])
#define will_lose_to(play) ("\002\000\001"[play])

/* ------------------------------------------------------------------------- */

static const int my_hist = 0,opp_hist = 1,both_hist = 2;

static int match_single(int i,int num,int *history) {
	int *highptr = history + num;
	int *lowptr = history + i;
	while (lowptr > history && *lowptr == *highptr) --lowptr, --highptr;
	return history + num - highptr;
}

static int match_both(int i,int num) {
	int j;
	for (j = 0; j < i && opp_history[num-j] == opp_history[i-j]
	                  && my_history[num-j]  == my_history[i-j]; ++j) ;
	return j;
}

static void do_history(int age,int best[3]) {
	const int num = my_history[0];
	int best_length[3],i,j,w;

	for (w = 0; w < 3; ++w) best[w] = best_length[w] = 0; 
	for (i = num - 1; i > num - age && i > best_length[my_hist]; --i) {
		j = match_single(i,num,my_history);
		if (j > best_length[my_hist]) {
			best_length[my_hist] = j;
			best[my_hist] = i;
			if (j > num / 2) break;
		}
	}

	for (i = num - 1; i > num - age && i > best_length[opp_hist]; --i) {
		j = match_single(i,num,opp_history);
		if (j > best_length[opp_hist]) {
			best_length[opp_hist] = j;
			best[opp_hist] = i;
			if (j > num / 2) break;
		}
	}

	for (i = num - 1; i > num - age && i > best_length[both_hist]; --i) {
		j = match_both(i,num);
		if (j > best_length[both_hist]) {
			best_length[both_hist] = j;
			best[both_hist] = i;
			if (j > num / 2) break;
		}
	}
}

/* ------------------------------------------------------------------------- */

struct stats {
	int sum[1 + trials][3];
	int age;
};

static void reset_stats(struct stats *st) {
	int i;
	st->age = 0;
	for (i = 0; i < 3; ++i) st->sum[st->age][i] = 0;
}

static void add_stats(struct stats *st,int i,int delta) {
	st->sum[st->age][i] += delta;
}

static void next_stats(struct stats *st) {
	if (st->age < trials) {
		int i;
		++(st->age);
		for (i = 0; i < 3; ++i) 
			st->sum[st->age][i] = st->sum[st->age - 1][i];
	}
}

static int max_stats(const struct stats *st,int age,int *which,int *score) {
	int i;
	*which = -1;
	for (i = 0; i < 3; ++i) {
		int diff;
		if (age > st->age) 
			diff = st->sum[st->age][i];
		else
			diff = st->sum[st->age][i] - st->sum[st->age - age][i];
		if (diff > *score) {
			*score = diff;
			*which = i;
		}
	}

	return -1 != *which;
}

/* ------------------------------------------------------------------------- */

struct predict {
	struct stats st;
	int last;
};

static void reset_predict(struct predict *pred) {
	reset_stats(&pred->st);
	pred->last = -1;
}

/* last: opponent's last move (-1 if none)
 | guess: algorithm's prediction of opponent's next move */
static void do_predict(struct predict *pred,int last,int guess) {
	if (-1 != last) {
		const int diff = (3 + last - pred->last) % 3;
		add_stats(&pred->st,will_beat(diff),1);
		add_stats(&pred->st,will_lose_to(diff),-1);
		next_stats(&pred->st);
	}

	pred->last = guess;
}

static void scan_predict(struct predict *pred,int age,int *move,int *score) {
	int i;
	if (max_stats(&pred->st,age,&i,score)) *move = ((pred->last + i) % 3);
}

/* ------------------------------------------------------------------------- */

static const int ages[] = { 1000, 100, 10, 5, 2, 1 };
#define num_ages (sizeof(ages) / sizeof(ages[0]))

struct iocaine {
	struct predict pr_history[num_ages][3][2],pr_freq[num_ages][2];
	struct predict pr_fixed,pr_random,pr_meta[num_ages];
	struct stats stats[2];
};

static int iocaine(struct iocaine *i) {
	const int num = my_history[0];
	const int last = (num > 0) ? opp_history[num] : -1;
	const int guess = biased_roshambo(1.0/3.0,1.0/3.0);
	int w,a,p;

	if (0 == num) {
		for (a = 0; a < num_ages; ++a) {
			reset_predict(&i->pr_meta[a]);
			for (p = 0; p < 2; ++p) {
				for (w = 0; w < 3; ++w)
					reset_predict(&i->pr_history[a][w][p]);
				reset_predict(&i->pr_freq[a][p]);
			}
		}
		for (p = 0; p < 2; ++p) reset_stats(&i->stats[p]);
		reset_predict(&i->pr_random);
		reset_predict(&i->pr_fixed);
	} else {
		add_stats(&i->stats[0],my_history[num],1);
		add_stats(&i->stats[1],opp_history[num],1);
	}

	for (a = 0; a < num_ages; ++a) {
		int best[3];
		do_history(ages[a],best);
		for (w = 0; w < 3; ++w) {
			const int b = best[w];
			if (0 == b) {
				do_predict(&i->pr_history[a][w][0],last,guess);
				do_predict(&i->pr_history[a][w][1],last,guess);
				continue;
			}
			do_predict(&i->pr_history[a][w][0],last,my_history[b+1]);
			do_predict(&i->pr_history[a][w][1],last,opp_history[b+1]);
		}

		for (p = 0; p < 2; ++p) {
			int best = -1,freq;
			if (max_stats(&i->stats[p],ages[a],&freq,&best))
				do_predict(&i->pr_freq[a][p],last,freq);
			else
				do_predict(&i->pr_freq[a][p],last,guess);
		}
	}

	do_predict(&i->pr_random,last,guess);
	do_predict(&i->pr_fixed,last,0);

	for (a = 0; a < num_ages; ++a) {
		int aa,score = -1,move = -1;
		for (aa = 0; aa < num_ages; ++aa) {
			for (p = 0; p < 2; ++p) {
				for (w = 0; w < 3; ++w)
					scan_predict(&i->pr_history[aa][w][p],
						     ages[a],&move,&score);
				scan_predict(&i->pr_freq[aa][p],ages[a],&move,&score);
			}
		}

		scan_predict(&i->pr_random,ages[a],&move,&score);
		scan_predict(&i->pr_fixed,ages[a],&move,&score);
		do_predict(&i->pr_meta[a],last,move);
	}

	{
		int score = -1,move = -1;
		for (a = 0; a < num_ages; ++a)
			scan_predict(&i->pr_meta[a],trials,&move,&score);
		return move;
	}
}

/* ------------------------------------------------------------------------- */

int iocainebot(void)
{
	static struct iocaine p;
	return iocaine(&p);
}

/* uniocaine */

/* human player */

int playernumber;

int human(void)
{
  char inchar;
  printf("Player %d, Make a move\n", playernumber);
  while (inchar != 'r' && inchar != 'p' && inchar != 's')
     {scanf("%c", &inchar);}
  if (inchar == 'r') {return 0;}
  else if (inchar == 'p') {return 1;}
  else if (inchar == 's') {return 2;}
}

/* unhuman player */


/*  End of RoShamBo Player Algorithms  */


void Init_Player_Table (Player_Table crosstable[players+1])
{
    int i, j;

    i = 0;  /* list of players in the tournament */
    strcpy(crosstable[i].name, "Player Name");

#ifdef Comment_Block  /* use these to comment out a block of players */

#endif Comment_Block  /* be sure to change the #define players value */

/* ask if player want to play, subs in randbot if not */

  char youin;
  printf("Do you want to play too?\n");
  while (youin != 'y' && youin != 'n')
     {scanf("%c", &youin);}
  if (youin == 'y') 
{
    i++;  /* human */
    strcpy(crosstable[i].name, "Human Player");
    crosstable[i].pname = human;
}
  else if (youin == 'n')
{
    i++;  /* choose uniformly at random */
    strcpy(crosstable[i].name, "* Random (Optimal)");
    crosstable[i].pname = randbot;
}

/* Computer Bots */

    i++;  /* iocaine */
    strcpy(crosstable[i].name, "Iocaine Powder");
    crosstable[i].pname = iocainebot;

    i++;  /* greenberg */
    strcpy(crosstable[i].name, "Greenberg");
    crosstable[i].pname = greenberg;


    for (i = 0; i <= players; i++) {
      for (j = 0; j <= players; j++) {
        crosstable[i].result[j] = 0;
      }
    }
}

int Play_Match ( int(*player1)(), int(*player2)() )
{
    /* play a match between two RoShamBo players */

    int i, j, p1, p2, p1total, p2total, ties;
    int p1hist[trials+1], p2hist[trials+1];
    char p1friendly, p2friendly;

    p1total = 0; p2total = 0; ties = 0;

    for (i = 0; i <= trials; i++) {
        p1hist[i] = 0; p2hist[i] = 0;
        my_history[i] = 0; opp_history[i] = 0;
    }

    for (i = 1; i <= trials; i++) {

        /* provide copies of history arrays for each player */
        memcpy(my_history, p1hist, sizeof(int)*(trials+1));
        memcpy(opp_history, p2hist, sizeof(int)*(trials+1));

        playernumber = 1;
        p1 = player1 ();              /* get player1 action */
        if ( (p1 < 0) || (p1 > 2) ) {
            printf("Error: return value out of range.\n");
            p1 = (p1 % 3 + 3) % 3;    /* note: -5 % 3 = -2, not 1 */
        }

        memcpy(opp_history, p1hist, sizeof(int)*(trials+1));
        memcpy(my_history, p2hist, sizeof(int)*(trials+1));

        playernumber = 2;
        p2 = player2 ();             /* get player2 action */
        if ( (p2 < 0) || (p2 > 2) ) {
            printf("Error: return value out of range.\n");
            p2 = (p2 % 3 + 3) % 3;
        }

        p1hist[0]++; p1hist[p1hist[0]] = p1;
        p2hist[0]++; p2hist[p2hist[0]] = p2;

        if (p1 == 0) {p1friendly = 'r';}
        else if (p1 == 1) {p1friendly = 'p';}
        else if (p1 == 2) {p1friendly = 's';}

        if (p2 == 0) {p2friendly = 'r';}
        else if (p2 == 1) {p2friendly = 'p';}
        else if (p2 == 2) {p2friendly = 's';}


        if (verbose1) { printf(" p1 = %c, p2 = %c ", p1friendly, p2friendly ); }
        if (p1 == p2) {
            ties++;
            if (verbose1) { printf(" tie!\n"); } }
        else if ( (p1-p2 == 1) || (p1-p2 == -2) ) {
            p1total++;
            if (verbose1) { printf(" p1 wins!\n"); } }
        else if ( (p2-p1 == 1) || (p2-p1 == -2) ) {
            p2total++;
            if (verbose1) { printf(" p2 wins!\n"); } }
        else printf("Error: should not be reached.\n");
    }
    if (verbose2) {
        printf(" Full history of p1 (%d trials):\n", p1hist[0]);
        for (j = 1; j <= trials; j++) {
            printf(" %d", p1hist[j]); }
        printf("\n");
        printf(" Full history of p2 (%d trials):\n", p1hist[0]);
        for (j = 1; j <= trials; j++) {
            printf(" %d", p2hist[j]); }
        printf("\n");
    }
    if (verbose3) {
        printf(" Match: %*d (%*d+ %*d- %*d=)\n", fw, p1total-p2total,
                            fw-1, p1total, fw-1, p2total, fw-1, ties);
    }

    return (p1total - p2total);
}

void Print_T_Results (Player_Table crosstable[players+1])
{
    int i, j;

    printf("\n Tournament results: \n\n");
    printf("    ");
    printf("%-*s ", nameleng, crosstable[0].name);
    printf("  total ");
    for (j = 1; j <= players; j++) {
        printf(" %*d", fw, j);
    }
    printf("\n");
    for (i = 1; i <= players; i++) {
        printf(" %2d ", i);
        printf("%-*s ", nameleng, crosstable[i].name);
        printf(" %*d ", fw+2, crosstable[i].result[0]);
        for (j = 1; j <= players; j++) {
            printf(" %*d", fw, crosstable[i].result[j]);
        }
        printf("\n");
    }
    printf("\n");
}

void Print_Sorted_Results (Player_Table crosstable[players+1])
{
    int i, j, max, swap;
    char nameswap[nameleng+1];

    Player_Table sorted[players+1];

    for (i = 0; i <= players; i++) {
        strcpy(sorted[i].name, crosstable[i].name);
        for (j = 0; j <= players; j++) {
            sorted[i].result[j] = crosstable[i].result[j];
        }
    }

    for (i = 1; i <= players; i++) {
        max = i;
        for (j = i; j <= players; j++) {
            if ( (sorted[j].result[0] > sorted[max].result[0]) ) {
                max = j;
            }
        }
        strcpy(nameswap, sorted[i].name);
        strcpy(sorted[i].name, sorted[max].name);
        strcpy(sorted[max].name, nameswap);
        for (j = 0; j <= players; j++) {
            swap = sorted[i].result[j];
            sorted[i].result[j] = sorted[max].result[j];
            sorted[max].result[j] = swap;
        }
        for (j = 1; j <= players; j++) {
            swap = sorted[j].result[i];
            sorted[j].result[i] = sorted[j].result[max];
            sorted[j].result[max] = swap;
        }
    }
    Print_T_Results (sorted);
}

void Print_Scaled_Results (Player_Table crosstable[players+1])
{
    int i, j, N;

    Player_Table stable[players+1];

    for (i = 0; i <= players; i++) {
        strcpy(stable[i].name, crosstable[i].name);
        for (j = 0; j <= players; j++) {
            stable[i].result[j] = crosstable[i].result[j];
        }
    }

    /* scale down set of N tournaments */
    N = tourneys;
    for (i = 1; i <= players; i++) {
        for (j = 0; j <= players; j++) {
            if ( stable[i].result[j] >= 0 ) {
                stable[i].result[j] = (stable[i].result[j] * 2 + N) / (2*N);
            }
            else {
                stable[i].result[j] = (stable[i].result[j] * 2 - N) / (2*N);
            }
        }
    }
    Print_Sorted_Results (stable);
}

void Print_M_Results (Player_Table crosstable[players+1])
{
    int i, j, win, draw, loss;

    printf("\n Match results: \n\n");
    printf("    ");
    printf("%-*s ", nameleng, crosstable[0].name);
    printf("   total  W  L  D ");
    for (j = 1; j <= players; j++) {
        printf(" %*d", fw-2, j);
    }
    printf("\n");
    for (i = 1; i <= players; i++) {
        printf(" %2d ", i);
        printf("%-*s ", nameleng, crosstable[i].name);
        printf(" %*d ", fw+2, crosstable[i].result[0]);
        win = 0; loss = 0; draw = -1;
        for (j = 1; j <= players; j++) {
            if ( crosstable[i].result[j] == 2 ) { win++; }
            if ( crosstable[i].result[j] == 0 ) { loss++; }
            if ( crosstable[i].result[j] == 1 ) { draw++; }
        }
        printf(" %2d %2d %2d ", win, loss, draw);
        for (j = 1; j <= players; j++) {
            printf(" %*d", fw-2, crosstable[i].result[j]);
        }
        printf("\n");
    }
    printf("\n");
}

void Print_MSorted_Results (Player_Table crosstable[players+1])
{
    int i, j, max, swap;
    char nameswap[nameleng+1];

    Player_Table sorted[players+1];

    for (i = 0; i <= players; i++) {
        strcpy(sorted[i].name, crosstable[i].name);
        for (j = 0; j <= players; j++) {
            sorted[i].result[j] = crosstable[i].result[j];
        }
    }

    for (i = 1; i <= players; i++) {
        max = i;
        for (j = i; j <= players; j++) {
            if ( (sorted[j].result[0] > sorted[max].result[0]) ) {
                max = j;
            }
        }
        strcpy(nameswap, sorted[i].name);
        strcpy(sorted[i].name, sorted[max].name);
        strcpy(sorted[max].name, nameswap);
        for (j = 0; j <= players; j++) {
            swap = sorted[i].result[j];
            sorted[i].result[j] = sorted[max].result[j];
            sorted[max].result[j] = swap;
        }
        for (j = 1; j <= players; j++) {
            swap = sorted[j].result[i];
            sorted[j].result[i] = sorted[j].result[max];
            sorted[j].result[max] = swap;
        }
    }
    Print_M_Results (sorted);
}

void Print_Match_Results (Player_Table crosstable[players+1])
{
    int i, j, N;

    Player_Table mtable[players+1];

    for (i = 0; i <= players; i++) {
        strcpy(mtable[i].name, crosstable[i].name);
        for (j = 0; j <= players; j++) {
            mtable[i].result[j] = crosstable[i].result[j];
        }
    }

    /* scale down set of N tournaments */
    N = tourneys;
    for (i = 1; i <= players; i++) {
        for (j = 0; j <= players; j++) {
            if ( mtable[i].result[j] >= 0 ) {
                mtable[i].result[j] = (mtable[i].result[j] * 2 + N) / (2*N);
            }
            else {
                mtable[i].result[j] = (mtable[i].result[j] * 2 - N) / (2*N);
            }
        }
    }
    /* Print_T_Results (mtable); */ /* scaled results */

    for (i = 1; i <= players; i++) {
        mtable[i].result[0] = -1;  /* account for "draw" vs self */
        for (j = 1; j <= players; j++) {
            if ( mtable[i].result[j] > drawn ) {
                mtable[i].result[j] = 2;
                mtable[i].result[0] += 2;
            }
            else if ( mtable[i].result[j] < -drawn ) {
                mtable[i].result[j] = 0;
            }
            else {
                mtable[i].result[j] = 1;
                mtable[i].result[0] += 1;
            }
        }
    }
    Print_MSorted_Results (mtable);
}

void Play_Tournament (Player_Table crosstable[players+1])
{
    int i, j, score;

    for (i = 1; i <= players; i++) {
        for (j = i+1; j <= players; j++) {
            if (verbose3) { printf(" %-*s vs %-*s\n", nameleng,
                crosstable[i].name, nameleng, crosstable[j].name); }
            score = Play_Match (crosstable[i].pname, crosstable[j].pname);
            crosstable[i].result[j] += score;
            crosstable[j].result[i] -= score;
        }
    }

    for (i = 1; i <= players; i++) {
        crosstable[i].result[0] = 0;
        for (j = 1; j <= players; j++) {
            crosstable[i].result[0] += crosstable[i].result[j];
        }
    }
    if (verbose2) { Print_T_Results (crosstable); }
}

int main() {

    int i;
    Player_Table crosstable[players+1];

    /* fixed or variable seed to the random() function */
    /* srandom(time(0)); */
    srand(time(0));

    Init_Player_Table (crosstable);

    printf(" Playing %d tournaments with %d trials per match...\n\n",
             tourneys, trials);

    for (i = 1; i <= tourneys; i++) {
        Play_Tournament (crosstable);
    }
    Print_Scaled_Results (crosstable);
    Print_Match_Results (crosstable);
    return(0);
}
