Readme
======

This archive contains two LaTeX packages, NewSmooth ans theshead. The easiest
way to use them is to put them in the same folder as the LaTeX document you're
working on, and use \usepackage{NewSmooth} or \usepackage{theshead}. It should 
also be possible to install theshead in your local texmf tree, although I
haven't tested this.

Both of these packages are released under the lppl, version 1.3. Additionally,
NewSmooth.sty can be used under the GPL, version 2. This document is released
into the public domain.

theshead.sty
############

This package is designed for people writing theses in amsbook. It modifies the
title page to include the date, department address, university logo, and degree
class. Most of this is automatic (if you have a document which already compiles
in amsbook, it should produce a similar title page, with the same information.
However, it also introduces several new elements:

\degreeclass{<degree classification>}
-------------------------------------

If your document includes this, the title page will include the text:

Thesis submitted for the degree of
<degree classification>

in the appropriate place.

A typical use would be:
\degreeclass{Doctor of Philosophy}

\logo{<graphical logo>}
-----------------------

If your document includes this, the titlepage will include <graphical logo>
in an appropriate place for a logo. I recommend you use the package graphicx
in your document, and use code similar to:

\logo{\includegraphics[height=4cm]{logo.png}}

Notes
-----

Additionally, for best results you should ensure that your document has a
\title, at least one \author, an \address, and a \date.

This style has only been tested with amsbook. It is likely to work with other
document classes derived from amsbook, but will not work with most other
classes, such as book.

For an example of this style in use, see my thesis, at
http://www.jamespic.me.uk/maths/Dissertation.tar.bz2

NewSmooth.sty
#############

This is a modified version of the beamer smoothtree theme. It has been modified
to allow colour changes during presentations. In presentations that do not
include colour changes, it has no advantages over smoothtree, and will compile slightly more slowly.

You can change the colour of subsequent slides with code such as the following:

\definecolor{refresh}{RGB}{255,0,0}
\setbeamercolor{structure}{fg=refresh}

which will give the presentation a red theme, as (255,0,0) corresponds to bright red.

For an example of this style in use, see
http://www.jamespic.me.uk/maths/Bangalore.tar.bz2
